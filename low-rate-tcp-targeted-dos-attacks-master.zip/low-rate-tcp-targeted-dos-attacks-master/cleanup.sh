#!/bin/bash

sudo rm -f *.txt results/*.txt *.png
