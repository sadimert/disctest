#!/bin/bash
set -euo pipefail

nc -l -p 12345 > /dev/null
